spool /share/TOOLS/Mask_KJ_imp/log/drop_ITK_SINKYOTU.log
set echo on
drop table TKC0DX12 cascade constraints purge;
drop table TOC0SE16 cascade constraints purge;
drop table WTBSGG21 cascade constraints purge;

spool off
exit

