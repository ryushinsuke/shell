spool /share/TOOLS/Mask_KJ_imp/log/drop_CMN.log
set echo on
drop table TOC0SE30 cascade constraints purge;
drop table TOC0SE31 cascade constraints purge;
drop table TOC0SE23 cascade constraints purge;

spool off
exit

