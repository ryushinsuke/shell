SPOOL /ext/bkwork/pmo/TOOLS/KMN_BACKUP/log/1003_kmn_2.lst
select table_name||','  from user_all_tables 
  where table_name like '%1003'            and table_name NOT IN ('TKPFZK01_1003','TKCMCD00_1003','TKCMCP00_1003','TKUSMS01_1003','TKUSSK01_1003','TKUSTH01_1003','TKUSZT01_1003') order by 1;
SPOOL OFF
