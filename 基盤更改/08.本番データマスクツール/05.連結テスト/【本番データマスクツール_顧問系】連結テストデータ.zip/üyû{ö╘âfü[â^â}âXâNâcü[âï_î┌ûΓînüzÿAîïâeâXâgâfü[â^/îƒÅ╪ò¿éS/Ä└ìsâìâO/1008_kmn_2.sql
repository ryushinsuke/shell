SPOOL /ext/bkwork/pmo/TOOLS/KMN_BACKUP/log/1008_kmn_2.lst
select table_name||','  from user_all_tables 
  where table_name like '%1008'            and table_name NOT IN ('TKPFZK01_1008','TKCMCD00_1008','TKCMCP00_1008','TKUSMS01_1008','TKUSSK01_1008','TKUSTH01_1008','TKUSZT01_1008') order by 1;
SPOOL OFF
