SPOOL /ext/bkwork/pmo/TOOLS/KMN_BACKUP/log/1001_kmn_2.lst
select table_name||','  from user_all_tables 
  where table_name like '%1001'            and table_name NOT IN ('TKPFZK01_1001','TKCMCD00_1001','TKCMCP00_1001','TKUSMS01_1001','TKUSSK01_1001','TKUSTH01_1001','TKUSZT01_1001') order by 1;
SPOOL OFF
