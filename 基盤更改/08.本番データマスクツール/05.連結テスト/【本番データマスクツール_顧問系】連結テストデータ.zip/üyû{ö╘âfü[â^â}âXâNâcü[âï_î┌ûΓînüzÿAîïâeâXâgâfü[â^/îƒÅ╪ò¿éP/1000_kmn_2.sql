SPOOL /ext/bkwork/pmo/TOOLS/KMN_BACKUP/log/1000_kmn_2.lst
select table_name||','  from user_all_tables 
  where (substr(table_name,length(table_name)-4,1) <> '_')            and table_name NOT IN ('TKCMCD00','TOC0SE16','TOC0SE30','TOC0SE31') order by 1;
SPOOL OFF
