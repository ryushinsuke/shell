#! /bin/sh
if [ $1 = "imp" ]; then
exit ${IMP_RETURN}
fi
if [ $1 = "exp" ]; then
exit ${EXP_RETURN}
fi

