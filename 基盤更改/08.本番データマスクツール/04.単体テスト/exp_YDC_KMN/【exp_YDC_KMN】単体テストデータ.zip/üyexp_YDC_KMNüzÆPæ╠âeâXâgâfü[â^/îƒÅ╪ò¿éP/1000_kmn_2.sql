SPOOL /ext/bkwork/pmo/TOOLS/KMN_BACKUP/log/1000_kmn_2.lst
select table_name||','  from user_all_tables 
  where (substr(table_name,length(table_name)-4,1) <> '_')            and table_name NOT IN ('TOC0EE11','TOC0EE12','TOC0EE13','TOC0EE14') order by 1;
SPOOL OFF
